(* HOURS WORKED *)
let hours_worked = [21; 21; 16; 40]
